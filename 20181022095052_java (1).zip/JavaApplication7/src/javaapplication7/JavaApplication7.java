/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication7;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author 1794421
 */
public class JavaApplication7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int noOfLines;
        int a;
        System.out.println("How many Lines ?");
        Scanner s = new Scanner(System.in);
        noOfLines = s.nextInt();
        Random randomObj = new Random();
        for (int i = 1; i <= noOfLines; i++) {
            System.out.println("");
            a = randomObj.nextInt(10);
            for (int j = 1; j <= 10; j++) {
                if(a == j){
                    System.out.print("*");
                }
                else{
                    System.out.print("-");
                }
            }
        }
    }
    
}
